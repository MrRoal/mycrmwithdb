<?php
/*+**********************************************************************************
 * The contents of this file are subject to the mycrm CRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  mycrm CRM Open Source
 * The Initial Developer of the Original Code is mycrm.
 * Portions created by mycrm are Copyright (C) mycrm.
 * All Rights Reserved.
 ************************************************************************************/

/*Config file for captcha
 * enabled webforms.
 */
global $captchaConfig;
$captchaConfig=array(
        'MYCRM_RECAPTCHA_PUBLIC_KEY'=>'RECAPTCHA PUBLIC KEY FOR THIS DOMAIN',//RECAPTCHA PUBLIC KEY FOR THIS DOMAIN
'MYCRM_RECAPTCHA_PRIVATE_KEY'=>'RECAPTCHA PRIVATE KEY FOR THIS DOMAIN');//RECAPTCHA PRIVATE KEY FOR THIS DOMAIN


