<?php
/*+**********************************************************************************
 * The contents of this file are subject to the mycrm CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  mycrm CRM Open Source
 * The Initial Developer of the Original Code is mycrm.
 * Portions created by mycrm are Copyright (C) mycrm.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
	'Potentials'                   => 'Affaires'                    , 
	'SINGLE_Potentials'            => 'Affaire'                     , 
	'LBL_ADD_RECORD'               => 'Add Opportunity'             , 
	'LBL_RECORDS_LIST'             => 'Opportunities List'          , 
	'LBL_OPPORTUNITY_INFORMATION'  => 'Détail'                     , 
	'Potential No'                 => 'Affaire N°'                 , 
	'Amount'                       => 'Montant'                     , 
	'Next Step'                    => 'Suivant'                     , 
	'Sales Stage'                  => 'Phase de vente'              , 
	'Probability'                  => 'Probabilité'                , 
	'Campaign Source'              => 'Campagne'                    , 
	'Forecast Amount'              => 'Forecast Amount'             , 
	'Funnel'                       => 'Sales Funnel'                , 
	'Potentials by Stage'          => 'Opportunities by Stage'      , 
	'Total Revenue'                => 'Revenue by Salesperson'      , 
	'Top Potentials'               => 'Top Opportunities'           , 
	'Forecast'                     => 'Sales Forecast'              , 
	'Prospecting'                  => 'Prospection'                 , 
	'Qualification'                => 'Qualification '              , 
	'Needs Analysis'               => 'A analyser'                  , 
	'Value Proposition'            => 'Proposition'                 , 
	'Id. Decision Makers'          => 'Ref décideurs'              , 
	'Perception Analysis'          => 'Analyse de perception'       , 
	'Proposal/Price Quote'         => 'Proposition/Prix'            , 
	'Negotiation/Review'           => 'Négociation/Révision'      , 
	'Closed Won'                   => 'Gagnée'                     , 
	'Closed Lost'                  => 'Perdue'                      , 
	'--None--'                     => '--Aucun--'                   , 
	'Existing Business'            => 'Client existant'             , 
	'New Business'                 => 'Nouveau client'              , 
	'LBL_EXPECTED_CLOSE_DATE_ON'   => 'Expected to close on'        , 
	'LBL_RELATED_CONTACTS'         => 'Related Contacts'            , // TODO: Review
	'LBL_RELATED_PRODUCTS'         => 'Related Products'            , // TODO: Review
        'Potentials Won'               =>'Potentiels gagnés',
);