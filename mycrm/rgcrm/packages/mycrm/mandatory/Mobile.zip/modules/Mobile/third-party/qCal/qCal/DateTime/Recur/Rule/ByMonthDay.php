<?php
class qCal_DateTime_Recur_Rule_ByMonthDay extends qCal_DateTime_Recur_Rule {

	public function getRecurrences() {
	
		return array();
	
	}

}