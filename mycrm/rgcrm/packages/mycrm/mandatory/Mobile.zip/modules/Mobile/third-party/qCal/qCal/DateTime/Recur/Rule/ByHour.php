<?php
class qCal_DateTime_Recur_Rule_ByHour extends qCal_DateTime_Recur_Rule {

	public function getRecurrences() {
	
		return array();
	
	}

}