<?php
/*+***********************************************************************************
 * The contents of this file are subject to the mycrm CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  mycrm CRM Open Source
 * The Initial Developer of the Original Code is mycrm.
 * Portions created by mycrm are Copyright (C) mycrm.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'LBL_ADD_RECORD' => 'Add Project Task',
	'LBL_PROJECTS_LIST' => 'Projects List',
	'LBL_PROJECT_TASK_INFORMATION' => 'Project Task Details',
	'LBL_RECORDS_LIST' => 'Project Task List',
	'LBL_TASKS_LIST' => 'Tasks List',
	'SINGLE_ProjectTask' => 'Project Task',
    'LBL_MILESTONES_LIST' => 'Milestones List',
     'Canceled ' => 'Cancelled',
);
